# Daily KPI Tracker for Central Lab - Design Guidelines

## Design Approach

**Selected System**: Material Design 3  
**Rationale**: Material Design excels at data-rich applications with its clear hierarchy, robust component library, and excellent support for forms, tables, and data visualization. Perfect for productivity tools requiring visual feedback and efficient information display.

## Core Design Principles

1. **Clarity First**: Every element serves a functional purpose in data comprehension
2. **Efficient Scanning**: Users should quickly locate and input data without friction
3. **Data Hierarchy**: Metrics and KPIs should have clear visual weight differentiation
4. **Consistent Patterns**: Repeated interactions across tabs maintain learned behaviors

---

## Typography

**Font Family**: Roboto (via Google Fonts CDN)
- Primary: Roboto (400, 500, 700)
- Mono: Roboto Mono (for numerical data)

**Hierarchy**:
- Page Headers: text-3xl font-bold (Roboto 700, 30px)
- Section Titles: text-xl font-semibold (Roboto 600, 20px)
- Card Headers: text-lg font-medium (Roboto 500, 18px)
- Body Text: text-base (Roboto 400, 16px)
- Data Labels: text-sm font-medium uppercase tracking-wide (Roboto 500, 14px)
- Metric Values: text-4xl font-bold font-mono (Roboto Mono 700, 36px)
- Table Data: text-sm font-mono (Roboto Mono 400, 14px)

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8, 12, 16** consistently
- Component padding: p-6 or p-8
- Section margins: mb-8 or mb-12
- Card gaps: gap-6
- Form field spacing: space-y-4
- Button padding: px-6 py-3

**Container Structure**:
- Max width: max-w-7xl mx-auto
- Page padding: px-4 lg:px-8
- Content sections: py-8

**Grid Layouts**:
- Dashboard cards: grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- Metric displays: grid grid-cols-2 lg:grid-cols-4 gap-4
- Form layouts: Single column with max-w-2xl

---

## Component Library

### Navigation
**Top Navigation Bar**:
- Fixed header with shadow-md elevation
- Container with logo/title on left, tab links center-right
- Height: h-16
- Tab links with active state indicator (bottom border, h-1, with subtle transition)
- Spacing between tabs: gap-8

### Cards (Material Design Elevated Cards)
**Standard Card**:
- Rounded corners: rounded-lg
- Shadow: shadow-lg with hover:shadow-xl transition
- Padding: p-6
- Border: border border-opacity-10

**Metric Card** (for KPI displays):
- Includes: Icon area (top), Large metric value (center), Label (bottom), Optional trend indicator
- Layout: flex flex-col items-center text-center
- Metric value: text-4xl font-bold font-mono
- Label: text-sm uppercase tracking-wide mt-2

**Chart Card**:
- Same as standard card
- Chart container: min-h-[300px] for consistency
- Chart title at top with divider (border-b pb-4 mb-4)

### Forms (Data Entry Tab)

**Form Container**:
- Max width: max-w-2xl mx-auto
- Card wrapper with p-8
- Form elements: space-y-6

**Form Fields**:
- Label above input: block text-sm font-medium mb-2
- Input fields: w-full px-4 py-3 rounded-md border focus:ring-2 focus:ring-offset-2
- Number inputs for counts: font-mono text-right
- Date picker: Full width with calendar icon (Heroicons)
- Select/Dropdown: Custom styled with chevron icon, py-3 px-4

**Employee Selector**:
- Large, prominent dropdown at top of form
- Label: "Select Employee" text-lg font-semibold mb-3
- Dropdown height: h-12

**Work Category Inputs**:
- Grid layout: grid grid-cols-1 md:grid-cols-2 gap-4
- Each field: Label with work type, number input aligned right
- Group by employee with subtle divider between sections

**Submit Button**:
- Full width on mobile, auto width on desktop: w-full md:w-auto
- Padding: px-8 py-3
- Rounded: rounded-md
- Positioned at bottom-right of form: md:ml-auto
- Icon + text: "Save Entry" with check icon (Heroicons)

### Tables (Recent Entries)

**Table Structure**:
- Full width with overflow-x-auto wrapper
- Striped rows for readability
- Header: Sticky top with font-semibold text-sm uppercase
- Cell padding: px-6 py-4
- Borders: border-b on rows

**Columns**:
- Date (left-aligned, font-mono)
- Employee (left-aligned)
- Work categories (right-aligned, font-mono)
- Actions (right-aligned, icon buttons)

### Charts (Recharts Library)

**Chart Styling**:
- Responsive container: width="100%" height={300}
- Bar Charts: Rounded bars with hover tooltips
- Pie Charts: With percentage labels and legend
- Grid lines: Subtle, dashed stroke
- Tooltips: Material Design style with shadow-lg, rounded-lg, p-3

**Chart Types by Section**:
- Dashboard: Bar chart for daily/monthly/yearly comparison, Pie chart for work distribution
- Individual KPI: Stacked bar chart for category breakdown, Line chart for trend over time

### Progress Indicators

**Linear Progress**:
- Height: h-2 or h-3
- Rounded: rounded-full
- Container with percentage label above: text-sm font-medium mb-2
- Target vs. achieved display: flex justify-between

**Circular Progress** (for dashboard overview):
- Size: w-24 h-24 for primary metrics
- Stroke width: 8
- Percentage in center: text-2xl font-bold

### Tabs (Individual Employee KPI Sub-navigation)

**Tab Container**:
- Border bottom: border-b
- Flex layout: flex space-x-8
- Tab buttons: pb-3 border-b-2 transition-colors
- Active state: border visible, inactive: border-transparent

### Data Visualization Hierarchy

**Dashboard Layout**:
- Hero metrics row: 4 key stats in grid grid-cols-2 lg:grid-cols-4 gap-4, mb-8
- Chart section: 2-column grid on desktop, stacked mobile
- Summary cards: 3-column grid with key insights

**Individual KPI Layout**:
- Employee selector at top with avatar placeholder
- Tab switcher for Daily/Monthly/Yearly
- Metric grid below tabs
- Charts in 2-column layout
- Detail table at bottom

### Export Functionality

**Export Button**:
- Position: Top-right of card/section
- Icon + text: Download icon (Heroicons) + "Export CSV"
- Size: px-4 py-2 text-sm
- Style: Outline button variant

---

## Icons

**Icon Library**: Heroicons (via CDN)  
**Common Icons**:
- Navigation: ChartBarIcon, DocumentTextIcon, UserGroupIcon
- Actions: PlusIcon, CheckIcon, DownloadIcon
- Data: CalendarIcon, ClockIcon, TrendingUpIcon
- Forms: ChevronDownIcon for dropdowns

**Icon Sizing**:
- Navigation: h-5 w-5
- Metric cards: h-8 w-8
- Form inputs: h-4 w-4
- Buttons: h-5 w-5

---

## Animations

**Minimal, Purposeful Animations**:
- Card hover: Subtle shadow increase (transition-shadow duration-200)
- Button states: Background transitions (transition-colors duration-150)
- Tab switching: Fade in content (fade-in 200ms)
- Chart rendering: Built-in Recharts animations (keep default)

**No Animations**:
- Page transitions
- Scroll effects
- Decorative motion

---

## Accessibility

- All form inputs have associated labels with `htmlFor` attributes
- Focus states visible on all interactive elements (ring-2 focus:ring-offset-2)
- ARIA labels for icon-only buttons
- Table headers use `<th>` with proper scope
- Chart data accessible via table fallback or ARIA descriptions
- Color contrast meets WCAG AA standards (handled by Material Design palette)
- Keyboard navigation supported for all interactive elements

---

## Responsive Behavior

**Mobile (< 768px)**:
- Single column layouts throughout
- Stacked navigation tabs if needed
- Full-width form elements
- Horizontal scroll for tables with sticky first column
- Charts scale to container width

**Tablet (768px - 1024px)**:
- 2-column grids for dashboard cards
- Form remains single column
- Tab navigation horizontal

**Desktop (> 1024px)**:
- 3-4 column grids for metrics
- 2-column chart layouts
- Side-by-side form elements where logical
- Fixed navigation bar with full menu

---

## Images

This application does **not require hero images** or decorative imagery. It is a data-focused productivity tool where:
- Employee avatars can be placeholder initials in circular containers (h-10 w-10 rounded-full)
- Icons serve all visual communication needs
- Charts and data visualizations are the primary visual elements
- Focus remains on information clarity and functional design