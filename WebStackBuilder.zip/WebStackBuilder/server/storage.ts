import { type User, type InsertUser, type KpiEntry, type InsertKpiEntry, type KpiSummary, type EmployeeKpi, EMPLOYEES } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createKpiEntry(entry: InsertKpiEntry): Promise<KpiEntry>;
  getKpiEntries(filters?: { startDate?: string; endDate?: string; employeeName?: string }): Promise<KpiEntry[]>;
  getAllKpiEntries(): Promise<KpiEntry[]>;
  getKpiSummary(period: "daily" | "monthly" | "yearly", startDate: string, endDate: string): Promise<KpiSummary>;
  getEmployeeKpi(employeeName: string, period: "daily" | "monthly" | "yearly", startDate: string, endDate: string): Promise<EmployeeKpi>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private kpiEntries: Map<string, KpiEntry>;

  constructor() {
    this.users = new Map();
    this.kpiEntries = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createKpiEntry(insertEntry: InsertKpiEntry): Promise<KpiEntry> {
    const id = randomUUID();
    const entry: KpiEntry = { ...insertEntry, id };
    this.kpiEntries.set(id, entry);
    return entry;
  }

  async getKpiEntries(filters?: { startDate?: string; endDate?: string; employeeName?: string }): Promise<KpiEntry[]> {
    let entries = Array.from(this.kpiEntries.values());

    if (filters?.startDate) {
      entries = entries.filter(e => e.entryDate >= filters.startDate!);
    }
    if (filters?.endDate) {
      entries = entries.filter(e => e.entryDate <= filters.endDate!);
    }
    if (filters?.employeeName) {
      entries = entries.filter(e => e.employeeName === filters.employeeName);
    }

    return entries.sort((a, b) => b.entryDate.localeCompare(a.entryDate));
  }

  async getAllKpiEntries(): Promise<KpiEntry[]> {
    return Array.from(this.kpiEntries.values()).sort((a, b) => 
      b.entryDate.localeCompare(a.entryDate)
    );
  }

  async getKpiSummary(period: "daily" | "monthly" | "yearly", startDate: string, endDate: string): Promise<KpiSummary> {
    const entries = await this.getKpiEntries({ startDate, endDate });

    const categoryMap = new Map<string, number>();
    const employeeMap = new Map<string, Map<string, number>>();

    entries.forEach(entry => {
      categoryMap.set(entry.workCategory, (categoryMap.get(entry.workCategory) || 0) + entry.count);

      if (!employeeMap.has(entry.employeeName)) {
        employeeMap.set(entry.employeeName, new Map());
      }
      const empCategories = employeeMap.get(entry.employeeName)!;
      empCategories.set(entry.workCategory, (empCategories.get(entry.workCategory) || 0) + entry.count);
    });

    const totalWorks = entries.reduce((sum, e) => sum + e.count, 0);
    
    const woReports = (categoryMap.get("WO REPORT") || 0);
    const iomReports = (categoryMap.get("IOM REPORT") || 0);
    const testSampleReports = (categoryMap.get("TEST SAMPLE TESTS") || 0) + 
                               (categoryMap.get("WO TESTS") || 0) + 
                               (categoryMap.get("IOM TESTS") || 0);

    const employeeBreakdown = Array.from(employeeMap.entries()).map(([employeeName, categories]) => {
      const categoryBreakdown = Array.from(categories.entries()).map(([category, count]) => ({
        category,
        count,
      }));
      const employeeTotal = categoryBreakdown.reduce((sum, c) => sum + c.count, 0);
      
      return {
        employeeName,
        totalWorks: employeeTotal,
        categoryBreakdown,
      };
    });

    const categoryBreakdown = Array.from(categoryMap.entries()).map(([category, count]) => ({
      category,
      count,
    }));

    return {
      period,
      totalWorks,
      woReports,
      iomReports,
      testSampleReports,
      employeeBreakdown,
      categoryBreakdown,
    };
  }

  async getEmployeeKpi(employeeName: string, period: "daily" | "monthly" | "yearly", startDate: string, endDate: string): Promise<EmployeeKpi> {
    const entries = await this.getKpiEntries({ startDate, endDate, employeeName });

    const categoryMap = new Map<string, number>();
    entries.forEach(entry => {
      categoryMap.set(entry.workCategory, (categoryMap.get(entry.workCategory) || 0) + entry.count);
    });

    const totalWorks = entries.reduce((sum, e) => sum + e.count, 0);
    const categoryBreakdown = Array.from(categoryMap.entries()).map(([category, count]) => ({
      category,
      count,
    }));

    return {
      employeeName,
      period,
      totalWorks,
      categoryBreakdown,
    };
  }
}

export const storage = new MemStorage();
