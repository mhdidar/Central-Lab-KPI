import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertKpiEntrySchema, EMPLOYEES } from "@shared/schema";
import { getTodayRange, getMonthRange, getYearRange } from "./date-utils";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/entries", async (req, res) => {
    try {
      const validatedData = insertKpiEntrySchema.parse(req.body);
      console.log("[KPI Entry] Creating:", validatedData);
      const entry = await storage.createKpiEntry(validatedData);
      const totalEntries = (await storage.getAllKpiEntries()).length;
      console.log("[KPI Entry] Created. Total entries:", totalEntries);
      res.json(entry);
    } catch (error: any) {
      console.error("[KPI Entry] Error:", error.message);
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/entries", async (req, res) => {
    try {
      const entries = await storage.getAllKpiEntries();
      res.json(entries);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/kpis/:period", async (req, res) => {
    try {
      const { period } = req.params;
      
      if (!["daily", "monthly", "yearly"].includes(period)) {
        return res.status(400).json({ error: "Invalid period" });
      }

      let dateRange;
      switch (period) {
        case "daily":
          dateRange = getTodayRange();
          break;
        case "monthly":
          dateRange = getMonthRange();
          break;
        case "yearly":
          dateRange = getYearRange();
          break;
        default:
          return res.status(400).json({ error: "Invalid period" });
      }

      const summary = await storage.getKpiSummary(
        period as "daily" | "monthly" | "yearly",
        dateRange.start,
        dateRange.end
      );

      res.json(summary);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/employee-kpi/:employeeName/:period", async (req, res) => {
    try {
      const { employeeName, period } = req.params;

      if (!EMPLOYEES.find(e => e.name === employeeName)) {
        return res.status(404).json({ error: "Employee not found" });
      }

      if (!["daily", "monthly", "yearly"].includes(period)) {
        return res.status(400).json({ error: "Invalid period" });
      }

      let dateRange;
      switch (period) {
        case "daily":
          dateRange = getTodayRange();
          break;
        case "monthly":
          dateRange = getMonthRange();
          break;
        case "yearly":
          dateRange = getYearRange();
          break;
        default:
          return res.status(400).json({ error: "Invalid period" });
      }

      const kpi = await storage.getEmployeeKpi(
        employeeName,
        period as "daily" | "monthly" | "yearly",
        dateRange.start,
        dateRange.end
      );

      res.json(kpi);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/employees", async (req, res) => {
    res.json(EMPLOYEES);
  });

  const httpServer = createServer(app);

  return httpServer;
}
