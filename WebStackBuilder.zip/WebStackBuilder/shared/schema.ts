import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const kpiEntries = pgTable("kpi_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeName: text("employee_name").notNull(),
  workCategory: text("work_category").notNull(),
  count: integer("count").notNull().default(0),
  entryDate: date("entry_date").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertKpiEntrySchema = createInsertSchema(kpiEntries).omit({
  id: true,
}).extend({
  count: z.number().min(0, "Count must be non-negative"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type KpiEntry = typeof kpiEntries.$inferSelect;
export type InsertKpiEntry = z.infer<typeof insertKpiEntrySchema>;

export interface Employee {
  name: string;
  workCategories: string[];
}

export const EMPLOYEES: Employee[] = [
  {
    name: "Didar",
    workCategories: ["WO REPORT", "YARN REPORT", "TC REPORT", "FABRIC STORE", "OTHERS"],
  },
  {
    name: "Rokib",
    workCategories: ["IOM REPORT", "DEFENCE REPORT", "RECEIVED IOM", "PROGRAMME", "OTHERS"],
  },
  {
    name: "Shuvo",
    workCategories: ["TRF", "UPLOADS", "REPORTS", "OTHERS"],
  },
  {
    name: "Redwan",
    workCategories: ["WO REPORT", "IOM REPORT", "WO TESTS", "IOM TESTS", "TEST SAMPLE TESTS"],
  },
];

export interface KpiSummary {
  period: "daily" | "monthly" | "yearly";
  totalWorks: number;
  woReports: number;
  iomReports: number;
  testSampleReports: number;
  employeeBreakdown: {
    employeeName: string;
    totalWorks: number;
    categoryBreakdown: { category: string; count: number }[];
  }[];
  categoryBreakdown: { category: string; count: number }[];
}

export interface EmployeeKpi {
  employeeName: string;
  period: "daily" | "monthly" | "yearly";
  totalWorks: number;
  categoryBreakdown: { category: string; count: number }[];
}
