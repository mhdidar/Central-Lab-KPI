import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  subtitle?: string;
  trend?: string;
  testId?: string;
}

export function MetricCard({ title, value, icon: Icon, subtitle, trend, testId }: MetricCardProps) {
  return (
    <Card className="p-6 hover-elevate transition-shadow" data-testid={testId}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
            {title}
          </p>
          <p className="mt-3 font-mono text-4xl font-bold text-foreground" data-testid={`${testId}-value`}>
            {value}
          </p>
          {subtitle && (
            <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>
          )}
          {trend && (
            <p className="mt-1 text-xs font-medium text-primary">{trend}</p>
          )}
        </div>
        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
          <Icon className="h-6 w-6 text-primary" />
        </div>
      </div>
    </Card>
  );
}
