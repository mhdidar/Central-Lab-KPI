import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { MetricCard } from "@/components/MetricCard";
import { ExportButton } from "@/components/ExportButton";
import { FileText, ClipboardCheck, TestTube, Users } from "lucide-react";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { exportToCSV } from "@/lib/csv-export";
import type { KpiSummary } from "@shared/schema";

const COLORS = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))", "hsl(var(--chart-4))", "hsl(var(--chart-5))"];

export default function Dashboard() {
  const { data: dailyData, isLoading: dailyLoading } = useQuery<KpiSummary>({
    queryKey: ["/api/kpis", "daily"],
  });

  const { data: monthlyData, isLoading: monthlyLoading } = useQuery<KpiSummary>({
    queryKey: ["/api/kpis", "monthly"],
  });

  const { data: yearlyData, isLoading: yearlyLoading } = useQuery<KpiSummary>({
    queryKey: ["/api/kpis", "yearly"],
  });

  const handleExport = (data: KpiSummary | undefined, period: string) => {
    if (!data) return;
    
    const exportData = data.employeeBreakdown.flatMap(emp =>
      emp.categoryBreakdown.map(cat => ({
        Period: period,
        Employee: emp.employeeName,
        Category: cat.category,
        Count: cat.count,
      }))
    );
    
    exportToCSV(exportData, `kpi-dashboard-${period}`);
  };

  const renderMetrics = (data: KpiSummary | undefined, isLoading: boolean) => {
    if (isLoading) {
      return (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="h-40 animate-pulse bg-muted/50" />
          ))}
        </div>
      );
    }

    if (!data) {
      return (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No data available</p>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Total Works"
          value={data.totalWorks}
          icon={ClipboardCheck}
          subtitle="All completed works"
          testId="metric-total-works"
        />
        <MetricCard
          title="WO Reports"
          value={data.woReports}
          icon={FileText}
          subtitle="Work Order Reports"
          testId="metric-wo-reports"
        />
        <MetricCard
          title="IOM Reports"
          value={data.iomReports}
          icon={FileText}
          subtitle="IOM Reports"
          testId="metric-iom-reports"
        />
        <MetricCard
          title="Test Samples"
          value={data.testSampleReports}
          icon={TestTube}
          subtitle="Test Sample Reports"
          testId="metric-test-samples"
        />
      </div>
    );
  };

  const renderCharts = (data: KpiSummary | undefined, isLoading: boolean) => {
    if (isLoading) {
      return (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card className="h-96 animate-pulse bg-muted/50" />
          <Card className="h-96 animate-pulse bg-muted/50" />
        </div>
      );
    }

    if (!data || data.employeeBreakdown.length === 0) {
      return (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No chart data available</p>
        </div>
      );
    }

    const employeeData = data.employeeBreakdown.map(emp => ({
      name: emp.employeeName,
      works: emp.totalWorks,
    }));

    const categoryData = data.categoryBreakdown
      .filter(cat => cat.count > 0)
      .map(cat => ({
        name: cat.category,
        value: cat.count,
      }));

    return (
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="p-6">
          <div className="mb-4 flex items-center justify-between border-b pb-4">
            <h3 className="text-lg font-semibold">Employee Performance</h3>
            <Users className="h-5 w-5 text-muted-foreground" />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={employeeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" tick={{ fill: "hsl(var(--foreground))" }} />
              <YAxis tick={{ fill: "hsl(var(--foreground))" }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--popover))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                }}
              />
              <Bar dataKey="works" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6">
          <div className="mb-4 flex items-center justify-between border-b pb-4">
            <h3 className="text-lg font-semibold">Work Distribution</h3>
            <ClipboardCheck className="h-5 w-5 text-muted-foreground" />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="hsl(var(--primary))"
                dataKey="value"
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--popover))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>
    );
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="mt-2 text-muted-foreground">
          Monitor Key Performance Indicators across all employees
        </p>
      </div>

      <Tabs defaultValue="daily" className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="daily" data-testid="tab-daily">Daily</TabsTrigger>
          <TabsTrigger value="monthly" data-testid="tab-monthly">Monthly</TabsTrigger>
          <TabsTrigger value="yearly" data-testid="tab-yearly">Yearly</TabsTrigger>
        </TabsList>

        <TabsContent value="daily" className="space-y-6" data-testid="content-daily">
          <div className="flex justify-end">
            <ExportButton onExport={() => handleExport(dailyData, "daily")} disabled={!dailyData} />
          </div>
          {renderMetrics(dailyData, dailyLoading)}
          {renderCharts(dailyData, dailyLoading)}
        </TabsContent>

        <TabsContent value="monthly" className="space-y-6" data-testid="content-monthly">
          <div className="flex justify-end">
            <ExportButton onExport={() => handleExport(monthlyData, "monthly")} disabled={!monthlyData} />
          </div>
          {renderMetrics(monthlyData, monthlyLoading)}
          {renderCharts(monthlyData, monthlyLoading)}
        </TabsContent>

        <TabsContent value="yearly" className="space-y-6" data-testid="content-yearly">
          <div className="flex justify-end">
            <ExportButton onExport={() => handleExport(yearlyData, "yearly")} disabled={!yearlyData} />
          </div>
          {renderMetrics(yearlyData, yearlyLoading)}
          {renderCharts(yearlyData, yearlyLoading)}
        </TabsContent>
      </Tabs>
    </div>
  );
}
