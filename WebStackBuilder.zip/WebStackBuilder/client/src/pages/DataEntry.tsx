import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate, formatDisplayDate } from "@/lib/date-utils";
import { CheckCircle, Calendar } from "lucide-react";
import { EMPLOYEES, type KpiEntry } from "@shared/schema";

const formSchema = z.object({
  employeeName: z.string().min(1, "Please select an employee"),
  entryDate: z.string().min(1, "Date is required"),
  counts: z.record(z.number().min(0, "Count must be non-negative")),
});

type FormData = z.infer<typeof formSchema>;

export default function DataEntry() {
  const { toast } = useToast();
  const [selectedEmployee, setSelectedEmployee] = useState<string>("");

  const { data: recentEntries, isLoading } = useQuery<KpiEntry[]>({
    queryKey: ["/api/entries"],
  });

  const mutation = useMutation({
    mutationFn: async (data: FormData) => {
      const entries = Object.entries(data.counts)
        .filter(([_, count]) => count > 0)
        .map(([category, count]) => ({
          employeeName: data.employeeName,
          workCategory: category,
          count,
          entryDate: data.entryDate,
        }));

      for (const entry of entries) {
        await apiRequest("POST", "/api/entries", entry);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/kpis"] });
      toast({
        title: "Success",
        description: "KPI data saved successfully",
      });
      reset();
      setSelectedEmployee("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save KPI data",
        variant: "destructive",
      });
    },
  });

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    watch,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      employeeName: "",
      entryDate: formatDate(new Date()),
      counts: {},
    },
  });

  const employee = EMPLOYEES.find((e) => e.name === selectedEmployee);

  const onSubmit = (data: FormData) => {
    mutation.mutate(data);
  };

  const handleEmployeeChange = (value: string) => {
    setSelectedEmployee(value);
    setValue("employeeName", value);
    const newCounts: Record<string, number> = {};
    const emp = EMPLOYEES.find((e) => e.name === value);
    emp?.workCategories.forEach((cat) => {
      newCounts[cat] = 0;
    });
    setValue("counts", newCounts);
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Data Entry</h1>
        <p className="mt-2 text-muted-foreground">
          Input daily work performance data for employees
        </p>
      </div>

      <Card className="mb-8 p-8">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="employee" className="text-sm font-medium">
                Select Employee
              </Label>
              <Select value={selectedEmployee} onValueChange={handleEmployeeChange}>
                <SelectTrigger
                  id="employee"
                  className="h-12"
                  data-testid="select-employee"
                >
                  <SelectValue placeholder="Choose an employee" />
                </SelectTrigger>
                <SelectContent>
                  {EMPLOYEES.map((emp) => (
                    <SelectItem key={emp.name} value={emp.name} data-testid={`option-employee-${emp.name.toLowerCase()}`}>
                      {emp.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.employeeName && (
                <p className="text-sm text-destructive">{errors.employeeName.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="entryDate" className="text-sm font-medium">
                Entry Date
              </Label>
              <div className="relative">
                <Input
                  id="entryDate"
                  type="date"
                  {...register("entryDate")}
                  className="h-12"
                  data-testid="input-date"
                />
                <Calendar className="absolute right-3 top-3 h-5 w-5 text-muted-foreground pointer-events-none" />
              </div>
              {errors.entryDate && (
                <p className="text-sm text-destructive">{errors.entryDate.message}</p>
              )}
            </div>
          </div>

          {employee && (
            <>
              <div className="border-t pt-6">
                <h3 className="mb-4 text-lg font-semibold">Work Categories</h3>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  {employee.workCategories.map((category) => (
                    <div key={category} className="space-y-2">
                      <Label htmlFor={category} className="text-sm font-medium">
                        {category}
                      </Label>
                      <Input
                        id={category}
                        type="number"
                        min="0"
                        {...register(`counts.${category}`, { valueAsNumber: true })}
                        className="h-12 font-mono text-right"
                        placeholder="0"
                        data-testid={`input-category-${category.toLowerCase().replace(/\s+/g, "-")}`}
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <Button
                  type="submit"
                  size="lg"
                  disabled={mutation.isPending}
                  className="gap-2"
                  data-testid="button-submit"
                >
                  <CheckCircle className="h-5 w-5" />
                  {mutation.isPending ? "Saving..." : "Save Entry"}
                </Button>
              </div>
            </>
          )}

          {!selectedEmployee && (
            <div className="rounded-lg border border-dashed p-12 text-center">
              <p className="text-muted-foreground">
                Select an employee to begin entering data
              </p>
            </div>
          )}
        </form>
      </Card>

      <Card className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold">Recent Entries</h2>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-12 animate-pulse rounded bg-muted/50" />
            ))}
          </div>
        ) : recentEntries && recentEntries.length > 0 ? (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Employee</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead className="text-right">Count</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentEntries.slice(0, 10).map((entry) => (
                  <TableRow key={entry.id} data-testid={`row-entry-${entry.id}`}>
                    <TableCell className="font-mono text-sm">
                      {formatDisplayDate(entry.entryDate)}
                    </TableCell>
                    <TableCell>{entry.employeeName}</TableCell>
                    <TableCell className="text-sm">{entry.workCategory}</TableCell>
                    <TableCell className="text-right font-mono font-semibold">
                      {entry.count}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="py-12 text-center">
            <p className="text-muted-foreground">No entries yet. Start by adding data above.</p>
          </div>
        )}
      </Card>
    </div>
  );
}
