import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { MetricCard } from "@/components/MetricCard";
import { ExportButton } from "@/components/ExportButton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ClipboardCheck, Target } from "lucide-react";
import { exportToCSV } from "@/lib/csv-export";
import { EMPLOYEES, type EmployeeKpi } from "@shared/schema";

const COLORS = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))", "hsl(var(--chart-4))", "hsl(var(--chart-5))"];

export default function EmployeeKpiPage() {
  const [selectedEmployee, setSelectedEmployee] = useState<string>("");
  const [period, setPeriod] = useState<"daily" | "monthly" | "yearly">("daily");

  const { data: kpiData, isLoading } = useQuery<EmployeeKpi>({
    queryKey: ["/api/employee-kpi", selectedEmployee, period],
    enabled: !!selectedEmployee,
  });

  const handleExport = () => {
    if (!kpiData) return;

    const exportData = kpiData.categoryBreakdown.map((cat) => ({
      Employee: kpiData.employeeName,
      Period: period,
      Category: cat.category,
      Count: cat.count,
    }));

    exportToCSV(exportData, `employee-kpi-${selectedEmployee}-${period}`);
  };

  const employee = EMPLOYEES.find((e) => e.name === selectedEmployee);

  const renderContent = () => {
    if (!selectedEmployee) {
      return (
        <Card className="p-12">
          <div className="text-center">
            <ClipboardCheck className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-4 text-lg font-semibold">Select an Employee</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Choose an employee from the dropdown to view their KPI performance
            </p>
          </div>
        </Card>
      );
    }

    if (isLoading) {
      return (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Card className="h-32 animate-pulse bg-muted/50" />
            <Card className="h-32 animate-pulse bg-muted/50" />
          </div>
          <Card className="h-96 animate-pulse bg-muted/50" />
        </div>
      );
    }

    if (!kpiData) {
      return (
        <Card className="p-12">
          <div className="text-center">
            <p className="text-muted-foreground">No data available for this employee</p>
          </div>
        </Card>
      );
    }

    const chartData = kpiData.categoryBreakdown
      .filter((cat) => cat.count > 0)
      .map((cat, index) => ({
        category: cat.category,
        count: cat.count,
        fill: COLORS[index % COLORS.length],
      }));

    return (
      <div className="space-y-6">
        <div className="flex justify-end">
          <ExportButton onExport={handleExport} />
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <MetricCard
            title="Total Works"
            value={kpiData.totalWorks}
            icon={ClipboardCheck}
            subtitle={`All work completed in ${period} period`}
            testId={`metric-employee-total-${period}`}
          />
          <MetricCard
            title="Categories"
            value={kpiData.categoryBreakdown.filter((c) => c.count > 0).length}
            icon={Target}
            subtitle="Active work categories"
            testId={`metric-employee-categories-${period}`}
          />
        </div>

        {chartData.length > 0 ? (
          <Card className="p-6">
            <div className="mb-4 flex items-center justify-between border-b pb-4">
              <h3 className="text-lg font-semibold">Work Category Breakdown</h3>
              <ClipboardCheck className="h-5 w-5 text-muted-foreground" />
            </div>
            <ResponsiveContainer width="100%" height={350}>
              <BarChart data={chartData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" tick={{ fill: "hsl(var(--foreground))" }} />
                <YAxis
                  type="category"
                  dataKey="category"
                  width={150}
                  tick={{ fill: "hsl(var(--foreground))", fontSize: 12 }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.5rem",
                  }}
                />
                <Bar dataKey="count" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        ) : (
          <Card className="p-12">
            <div className="text-center">
              <p className="text-muted-foreground">
                No work completed in this period
              </p>
            </div>
          </Card>
        )}

        <Card className="p-6">
          <h3 className="mb-4 text-lg font-semibold">Detailed Breakdown</h3>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
            {employee?.workCategories.map((category) => {
              const data = kpiData.categoryBreakdown.find((c) => c.category === category);
              const count = data?.count || 0;
              return (
                <div
                  key={category}
                  className="flex items-center justify-between rounded-lg border p-4 hover-elevate"
                  data-testid={`category-${category.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  <span className="text-sm font-medium">{category}</span>
                  <span className="font-mono text-lg font-bold text-primary">{count}</span>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    );
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Individual Employee KPI</h1>
        <p className="mt-2 text-muted-foreground">
          Detailed performance analysis for individual employees
        </p>
      </div>

      <Card className="mb-8 p-6">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium">Select Employee</label>
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger className="h-12" data-testid="select-employee-kpi">
                <SelectValue placeholder="Choose an employee" />
              </SelectTrigger>
              <SelectContent>
                {EMPLOYEES.map((emp) => (
                  <SelectItem key={emp.name} value={emp.name} data-testid={`option-employee-kpi-${emp.name.toLowerCase()}`}>
                    {emp.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedEmployee && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Time Period</label>
              <Tabs value={period} onValueChange={(v) => setPeriod(v as "daily" | "monthly" | "yearly")} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="daily" data-testid="tab-period-daily">Daily</TabsTrigger>
                  <TabsTrigger value="monthly" data-testid="tab-period-monthly">Monthly</TabsTrigger>
                  <TabsTrigger value="yearly" data-testid="tab-period-yearly">Yearly</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          )}
        </div>
      </Card>

      {renderContent()}
    </div>
  );
}
