import { format, startOfDay, startOfMonth, startOfYear, endOfDay, endOfMonth, endOfYear } from "date-fns";

export function formatDate(date: Date | string): string {
  return format(new Date(date), "yyyy-MM-dd");
}

export function formatDisplayDate(date: Date | string): string {
  return format(new Date(date), "MMM dd, yyyy");
}

export function getTodayRange() {
  const now = new Date();
  return {
    start: formatDate(startOfDay(now)),
    end: formatDate(endOfDay(now)),
  };
}

export function getMonthRange() {
  const now = new Date();
  return {
    start: formatDate(startOfMonth(now)),
    end: formatDate(endOfMonth(now)),
  };
}

export function getYearRange() {
  const now = new Date();
  return {
    start: formatDate(startOfYear(now)),
    end: formatDate(endOfYear(now)),
  };
}
