# Daily KPI Tracker for Central Lab

## Overview

This is a full-stack web application for tracking daily Key Performance Indicators (KPIs) in a Central Lab environment. The application enables operators to input work performance data for individual employees across different work categories (reports, tests, samples, etc.) and provides comprehensive dashboards to visualize daily, monthly, and yearly performance metrics.

The system tracks four employees (Didar, Rokib, Shuvo, and Redwan), each with their own specific work categories. It aggregates this data to show individual employee progress as well as overall lab performance with interactive charts and data visualizations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Client-side routing with Wouter (lightweight React Router alternative)
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation via @hookform/resolvers
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom Material Design 3-inspired theme

**Design System**:
- Material Design 3 principles selected for data-rich applications
- Custom color system using CSS variables with HSL format for theming
- Typography: Roboto font family for UI, Roboto Mono for numerical data
- Consistent spacing system using Tailwind's spacing units (2, 4, 6, 8, 12, 16)
- Component variants managed through class-variance-authority

**Key Pages**:
1. **Dashboard**: Displays aggregated KPI metrics (daily/monthly/yearly) with charts showing overall lab performance
2. **Data Entry**: Form-based interface for operators to input employee work data with date selection
3. **Employee KPI**: Individual employee performance view with category breakdowns and progress tracking

### Backend Architecture

**Server Framework**: Express.js with TypeScript
- **Development Server**: Vite middleware integration for HMR (Hot Module Reload)
- **API Pattern**: RESTful API endpoints under `/api` prefix
- **Request Handling**: JSON body parsing with raw body preservation for webhooks
- **Logging**: Custom request/response logging for API endpoints

**API Endpoints**:
- `POST /api/entries` - Create new KPI entries
- `GET /api/entries` - Retrieve all KPI entries with optional filtering
- `GET /api/kpis/:period` - Get aggregated KPI summaries (daily/monthly/yearly)
- `GET /api/employee-kpi/:employeeName/:period` - Get individual employee metrics

**Data Storage**:
- Currently using in-memory storage (MemStorage class) for development
- Schema defined with Drizzle ORM for PostgreSQL migration path
- Ready for Neon serverless PostgreSQL integration (@neondatabase/serverless)

### Data Schema

**Database Tables** (defined via Drizzle ORM):

1. **users**: User authentication
   - id (UUID primary key)
   - username (unique)
   - password

2. **kpi_entries**: Core work entry records
   - id (UUID primary key)
   - employeeName (text)
   - workCategory (text)
   - count (integer, default 0)
   - entryDate (date)

**Validation**: Zod schemas ensure:
- Non-negative counts for work entries
- Required fields (employee name, work category, entry date)
- Type safety across client and server

**Employee Configuration**: Hardcoded in schema.ts
- Didar: WO REPORT, YARN REPORT, TC REPORT, FABRIC STORE, OTHERS
- Rokib: IOM REPORT, DEFENCE REPORT, RECEIVED IOM, PROGRAMME, OTHERS
- Shuvo: TRF, UPLOADS, REPORTS, OTHERS
- Redwan: WO REPORT, IOM REPORT, WO TESTS, IOM TESTS, TEST SAMPLE TESTS

### Data Visualization

**Charting Library**: Recharts (React wrapper for D3)
- Bar charts for category comparisons
- Pie charts for distribution visualization
- Responsive containers for mobile compatibility
- Custom color palette using CSS variables

**Aggregation Logic**:
- Date range calculations in both client and server utilities (date-fns on client, custom formatters on server)
- Summary calculations for daily/monthly/yearly periods
- Employee-specific and category-specific breakdowns

### Build & Deployment

**Development**:
- `npm run dev` - Starts development server with Vite HMR
- TypeScript compilation checking via `npm run check`
- Database schema push via `npm run db:push` (Drizzle Kit)

**Production Build**:
- Client: Vite builds React app to `dist/public`
- Server: esbuild bundles Express server to `dist/index.js`
- Single Node.js process serves both static files and API

**Path Aliases**:
- `@/` → `client/src/`
- `@shared/` → `shared/`
- `@assets/` → `attached_assets/`

## External Dependencies

### Primary Dependencies

**UI & Styling**:
- @radix-ui/* (v1.x) - Accessible component primitives for dialogs, dropdowns, tabs, etc.
- tailwindcss - Utility-first CSS framework
- class-variance-authority - Type-safe component variants
- lucide-react - Icon library

**Forms & Validation**:
- react-hook-form - Form state management
- zod - Runtime type validation
- @hookform/resolvers - Zod integration for React Hook Form

**Data & State**:
- @tanstack/react-query (v5.x) - Server state management and caching
- drizzle-orm (v0.39.x) - Type-safe SQL ORM
- drizzle-zod - Generate Zod schemas from Drizzle tables

**Database**:
- @neondatabase/serverless - PostgreSQL driver for Neon (serverless)
- pg - PostgreSQL client (via Drizzle)
- connect-pg-simple - PostgreSQL session store for Express

**Visualization**:
- recharts - React charting library

**Utilities**:
- date-fns - Date manipulation and formatting
- clsx & tailwind-merge - Class name utilities
- nanoid - Unique ID generation

### Development Dependencies

- vite - Build tool and dev server
- @vitejs/plugin-react - React support for Vite
- tsx - TypeScript execution for development
- esbuild - Server bundling for production
- drizzle-kit - Database migration tool
- @replit/vite-plugin-* - Replit-specific development enhancements

### Future Migration Notes

The application is architected to migrate from in-memory storage to PostgreSQL:
1. Database URL configured via `DATABASE_URL` environment variable
2. Drizzle schema already defined for `users` and `kpi_entries` tables
3. Migration path: Replace `MemStorage` with Drizzle queries in `storage.ts`
4. Session management ready via `connect-pg-simple`